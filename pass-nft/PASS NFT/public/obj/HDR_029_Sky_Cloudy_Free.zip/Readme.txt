This package contains a high resolution hdri environment bundled together with its sIBL set.
You can find more information about sIBL in "What-is-sIBL.txt".

Besides those HDRI skies we also have a lot of super high resolution textures.

Weblinks:
http://www.hdri-hub.com
https://www.facebook.com/hdrihub

If you have any questions just send us a mail: info@hdri-hub.com

With regards

Your HDRI Hub team